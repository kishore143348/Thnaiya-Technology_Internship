


// let a = 20
// let p = new Promise((resolve,reject)=>{
//     if (a==20){
//         resolve("A is matching")
//     }
//     else{
//         reject("A is not matching ")
//     }

// })
// console.log(typeof p);
// console.log(p);





// let a = 20
// let p = new Promise((resolve,reject)=>{
//     if (a==20){
//         resolve("A is matching")
//     }
//     else{
//         reject("A is not matching ")
//     }

// })
// p.then((resolvedData)=>{
//     console.log("data:-",resolvedData);
// }).catch((rejectedData)=>{
//     console.log("error:-",rejectedData)
// })
// console.log(p);



// let student = [
//     {
//         name:"miller",
//         age:24,
//         gender:"male"
//     },
//     {
//         name:"mille",
//         age:24,
//         gender:"male"
//     },
//     {
//         name:"mill",
//         age:24,
//         gender:"male"
//     },
//     {
//         name:"miler",
//         age:24,
//         gender:"male"
//     },
//     {
//         name:"mier",
//         age:24,
//         gender:"male"
//     },
    
// ]

// let p = new Promise((resolve,reject)=>{
//     if(student.length>0){
//         resolve({data:student,message:"data fetched successfully"})
//     }
//     else{
//         reject({data:null,message:"no data found"})
//     }
// })

// console.log(p);

// p.then((res)=>{
//     console.log(res.data);

//     let stdlist = document.getElementById("list")
//     res.data.map(({name,age,gender})=>{
        
//         return stdlist.innerHTML+=`
//         <li>${name}</li>
//         <li>${age}</li>
//         <li>${gender}</li>
//         `
//     })
// }).catch((err)=>{
  
//     let stdlist = document.getElementById("list")

//     return stdlist.innerHTML+=`
//         <li>${err.message}</li>`
// })


let g = fetch("https://fakestoreapi.com/products")
.then(response=>response.json())
.then(data=>console.log("fetcheddata:-",data))


