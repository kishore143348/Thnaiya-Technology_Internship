// ? exception handling  

// const s = "hello javascript"
// console.log(s);

// try{
//     const r = s.replace("javascript","reactjs")
//     console.log(r);
// }catch(err){
//     console.log(err.message);
// }


//? async and await 

// let a = 3;

// let p = new Promise((resolve,reject)=>{

//     if (a === 2){
//         resolve("A is equal to 2")
//     }
//     else{
//         reject("error")
//     }
// })

// async function getValue() {

//     try{
//         let res= await p
//         console.log(res);
//     }catch(err){
//         console.log(err.message);
//     }
    
// }
// getValue()


//? this keyword in javascript

// console.log(this);  // it refers to window 

// function demo(){
//     console.log(this);  // it refers to window
// }
// demo()

// !================
// let student = {

//     name : "john",
//     age : 25,
//     details:function(){
//         console.log(this);
//         console.log(`My name is ${this.name} and my age is ${this.age}` );
//     }

// }
// console.log(student.name);

// student.details()

//! ======================

// "use strict"

// function demo(){
//     console.log(this);

// }

// demo()      /// undefined when we use strict mode 


// "use srtict"
// let demo = ()=>{
//     console.log(this);
// }

// demo() /// arrow function always refer to a window object

//? closure 

function test(){
    var a = 2
    return function(){
        var b=3
        console.log(a+b);
    }
}

let add = test()
add()
