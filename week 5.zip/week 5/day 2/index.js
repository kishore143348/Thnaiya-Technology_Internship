//? freeze and seal method()
// let student = {name:"sheela",age:34,dept:"cse"}
// console.log(student);

// console.log(Object.keys(student));
// console.log(Object.values(student));
// console.log(Object.entries(student));

//==================================
// Object.freeze(student)
// student.dept="Mech"
// console.log(student);

// console.log(Object.isFrozen(student));

//=========================

// Object.seal(student)
// student.age="32"
// console.log(student);

// console.log(Object.isSealed(student));

//? spread operator ()

// let student = {name:"sheela",age:34,dept:"cse",marks:{math:50,scs:60,hin:40}}
// console.log("Student:-" ,student);

// let emp = {...student}
// console.log("Emp:-",emp)

// student.gender="female"
// console.log("Student:-" ,student);
// emp.salary = 30000;
// console.log("Emp:-",emp)

// student.marks.Eng = 100
// console.log(student);
// console.log("Student:-" ,student);
// console.log("Emp:-",emp)

//? rest parameter 

// function add(a,b,...c){   // a=2,b=4, c=5,6,7,1,8,9
//     console.log(a,b,c);
// }
// add(2,4,5,6,7,1,8,9)

//? destructuring 

//? array

let colors = ["red","blue","green","violet","black"]
console.log(colors);

let [z,b,...r] = colors
console.log(z,b,r);

//? object 


