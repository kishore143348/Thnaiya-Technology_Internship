//? javascript objects


// let student = {name:"laila",age:23,marks:420}
///======{name: 'laila', age: 23, marks: 420}
// let student = {name:"laila",age:23,marks:420,name:"manju"}
//====={name: 'laila', age: 23, marks: 420}
// console.log(student);


//  ~ CRUD operations

//? create 

let student = {name:"laila",age:23,marks:420}

console.log(student);

student.dept='cse'

console.log(student);

//? read 

let student1 = {name:"laila",age:23,marks:420}
console.log(student1);
console.log(student1.marks);

//? update 

let student2 = {name:"laila",age:23,marks:420}
console.log(student2);
student2.age=30;
console.log(student2);

//? delete

let student3 = {name:"laila",age:23,marks:420}
console.log(student3);

delete student3.marks
console.log(student3);


// ============================

let student4 = {name:"laila",age:23,marks:420,dept:"CSE"}
console.log(student4);

// for (let std of student4) {

//     console.log(std);
    
// }

// for (let std in student4) {
    
//     console.log(std);
    
// }

//=======output
//              name
// index.js:58 age
// index.js:58 marks
// index.js:58 dept

// ===============================

let student5 = {name:"laila",age:23,marks:420,dept:"CSE",gender:"f"}
console.log(student5);

for (const key in student5) {

    console.log(key);
    console.log(typeof key)
    
    }

/// output ===========

//              name
// index.js:76 string
// index.js:75 age
// index.js:76 string
// index.js:75 marks
// index.js:76 string
// index.js:75 dept
// index.js:76 string
// index.js:75 gender
// index.js:76 string


//? object literals
let student6 = {name:"laila",age:23,marks:420,dept:"CSE",gender:"f"}
console.log(student6);



//? using inbuilt objects 

let std = new Object()

std.name = "raj",
std.age = 25 ,
std.dept = "sce"

console.log(std);

//? using constructor function 

function stud(name,age,dept) {

    this.sname=name;
    this.sage=age;
    this.sdept=dept;

}

let s = new stud("john",34,"civil")
console.log(s);

//======= output ==== stud {sname: 'john', sage: 34, sdept: 'civil'}


//? using classes 

class std1{
    name = "miller";
    age = 45;
    dept= "mech";
}
let s1 = new std1()
console.log(s1);


//? using create method


let student77 = {name:"laila",age:23,marks:420,dept:"CSE",gender:"f"}
console.log(student77);

let newstudent = Object.create(student77)
console.log(student77);
console.log(newstudent.name);





