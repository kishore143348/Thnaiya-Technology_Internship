//? forof method

// let colors = ["red","blue","green","yellow","orange"]

// console.log(colors);

// for (const element of colors) {

//     console.log(element)
// }

//? forin method

// let colors = ["red","blue","green","yellow","orange"]

// console.log(colors);

// for (const element in colors) {

//     console.log(element)
// }

//syntax  of forin

// for (const key in object) {
//     if (Object.prototype.hasOwnProperty.call(object, key)) {
//         const element = object[key];
        
//     }
// }


//? is array() method

// let colors = ["red","blue","green","yellow","orange"]

// console.log(colors);

// let b=50;

// console.log(Array.isArray(b));
// // console.log(Array.isArray(colors));

//? fromArray() method

// let obj={0:"apple",1:"orange",2:"banana",length:3}
// let array = Array.from(obj)
// console.log(array);

//=============(3) ['apple', 'orange', 'banana']

// let str='javascript'

// let array=Array.from(str)
// console.log(array)
//==============(10) ['j', 'a', 'v', 'a', 's', 'c', 'r', 'i', 'p', 't']


//? falsy values 

let numbers = [null,undefined,true,NaN,"0"]

let res = numbers.map((numbers)=>{
    if(numbers){
        return "hi"
    }
    return "hello"
})
console.log(res);