// //? every

// let numbers = [2,4,6,8,10]
// console.log(numbers);

// let res = numbers.every((numbers)=>{
//     console.log("hello");
//     return  numbers > 5

// })

// console.log(res);

// //? some

// let numbers = [2,4,6,8,10]
// console.log(numbers);

// let res = numbers.some((numbers)=>{
//     console.log("hello");
//     return  numbers > 1

// })

// console.log(res);

//? find 


// let numbers = [2,4,6,8,10]
// console.log(numbers);

// let res = numbers.find((numbers)=>{
//     console.log("hello");
//     // return  numbers > 4
//     return  numbers > 10
// })

// console.log(res);


//? findindex


// let numbers = [2,4,6,8,10]
// console.log(numbers);

// let res = numbers.findIndex((numbers)=>{
//     console.log("hello");
//     return  numbers > 4
//     // return  numbers > 10
// })

// console.log(res);


//? sort 

//? find 


let numbers = [2,14,46,81,10]
console.log(numbers);

let res = numbers.find((n1,n2)=>{
    console.log("hello");
    // return  numbers > 4
    return  n1-n2
})

console.log(res);



