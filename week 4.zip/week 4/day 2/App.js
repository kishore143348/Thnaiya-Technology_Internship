// ? slice ()

// let colors=["red","black","pink","blue","hotpink","brown"]
// console.log(colors);

// let res = colors.slice(1,3)
//      // let res = colors.slice(1)

// console.log(colors);
// console.log(res);

//? includes


// let colors=["red","black","pink","blue","hotpink","brown"]
// console.log(colors);

// let res = colors.includes("pink",1)
// // let res = colors.includes("pink")


// console.log(colors);
// console.log(res);

//? indexOf()

// let colors=["red","black","pink","blue","hotpink","brown"]
// console.log(colors);

// // let res = colors.indexOf("pink",4)
// let res = colors.indexOf("pink")
// console.log(res);


//? at()

// let colors=["red","black","pink","blue","hotpink","brown"]
// console.log(colors);

// // let res = colors.at(3)
// let res = colors.at("6")
// console.log(res);

//? concat() 

// let colors=["red","black","pink","blue","hotpink","brown"]
// console.log(colors);

// // let res = colors.concat(3)
// let res = colors.concat("indigo",234)
// console.log(res);

//? join ()

// let colors=["red","black","pink","blue","hotpink","brown"]
// console.log(colors);

// // let res = colors.join("/")
// // let res = colors.join("")
// let res = colors.join()  // by default it takes ,
// console.log(res);

//? fill()

let colors=["red","black","pink","blue","hotpink","brown"]
console.log(colors);


// let res = colors.fill("orange",2,4) // it changes index pos 2 - 4 with orange and prints new array
// let res = colors.fill("orange",2)      // if end pos doesn't provided then from starting pos to end it prints the same element
let res = colors.fill(2,3,5)        // here 2 (element), 3(start pos),5(end pos)
console.log(res);


//? lastindexof ()

// let colors=["red","black","pink","blue","hotpink","brown"]
// console.log(colors);

// let res = colors.lastIndexOf("red",3) //it starts searching the array from behind 5,4,3,2,1,0 here 3-->blue it starts from there in reverse order so //!red--->0//
// // let res = colors.lastIndexOf("black")   // but if we use only 1 argument it works as indexof (finds the index of element)
// console.log(res);