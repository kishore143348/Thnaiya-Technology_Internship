//! Array literals
// let array= [10,"hello",null]

// console.log(array);


// !constructors

// let array=new Array(1,2,3)

// console.log(array);

// let array=new Array("hi")

// console.log(array);

// let array=new Array(1)

// console.log(array);

// !array.OF

// let array=Array.of(10,20)
// console.log(array);

//! arrray methods
//! helper method
//! push
// let array=[10,20,30,40,50]

// console.log(array);

// let res = array.push(60)
// console.log(array);
// console.log(res);


//! unshift

// let array=[10,20,30,40,50]

// console.log(array);

// let res = array.unshift(5)
// console.log(array);
// console.log(res);

//! pop

// let array=[10,20,30,40,50]

// console.log(array);

// let res = array.pop()
// console.log(array);
// console.log(res);

//! shift 
// let array=[10,20,30,40,50]

// console.log(array);

// let res = array.shift()
// console.log(array);
// console.log(res);

//! splice

let colors=["red","green","blue","pink","orange"]

console.log(colors);

// let res = colors.splice(1,3,"brown") // 1- starting point (0,1,2,3...), 3- is deleting range (here it deletes green , blue , pink), "brown"- it is added at the deleted place
// let res = colors.splice(1,0,"brown")   // it won't delete any colors
// let res = colors.splice(1,3) // if you dont want to add  any colors
let res = colors.splice(1)    // it deletes the entire array from the mentioned argument
console.log(colors);
console.log(res);