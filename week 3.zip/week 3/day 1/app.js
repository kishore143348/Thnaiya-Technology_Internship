let a = 10

console.log(a);


// primitive datatypes numbers,strings,boolean,null,undefined,Bigint,symbol

// obejects(), Array(), promise(),Date(), Math()

// arithmatic operators

c=20
b=10


console.log(c+b);
console.log(c-b);
console.log(c*b);
console.log(c**b);

aa=12
bb=13
cc=14

console.log(aa/bb);
console.log(aa-bb);
console.log(cc-bb+bb);
console.log(aa*bb-cc);





// assignment operators

m=12
m=+4
// changes m value 12 to 4
console.log(m);

k=17
k+=4
// k+4==17+4=21
console.log(k);

s=10
s=-3
// changes s value 10 to -3
console.log(s);

d=15
d+=2
// d+2==15+2=17
console.log(d);

// unary operators

// decrement --
// post decrement a--
// pre decrement --a

// increment ++
// post increment a++
// pre increment ++a

z=10
z++
console.log(z);

vv = 11
--vv     
// 11-1=10
xx = 22
xx--   
// 22-1=21
nn = 33
++nn
// 33+1=34
mm = 44
mm++
// 44+1=45

console.log(vv);
console.log(xx);
console.log(nn);
console.log(mm);

mv= mm-- + vv
// 44 + 11 = 55  performs just addition 
console.log(mv);


